from django.contrib import admin

from ciifen.pluviograma.models import Pluviograma, Modelo

# Register your models here.

admin.site.register(Pluviograma)
admin.site.register(Modelo)
