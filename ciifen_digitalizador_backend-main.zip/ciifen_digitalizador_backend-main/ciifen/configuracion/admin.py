from django.contrib import admin

from ciifen.configuracion.models import DetalleUsuario

# Register your models here.
admin.site.register(DetalleUsuario)