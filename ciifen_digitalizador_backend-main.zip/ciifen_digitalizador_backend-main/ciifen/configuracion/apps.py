from django.apps import AppConfig


class ConfiguracionConfig(AppConfig):
    name = 'ciifen.configuracion'