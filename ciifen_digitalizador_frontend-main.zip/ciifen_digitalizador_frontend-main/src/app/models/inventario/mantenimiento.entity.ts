export class Matenimiento {
  id: string;
  tipo: string;
  fecha: string;
  detalle: string;
  instrumento: string;
}
