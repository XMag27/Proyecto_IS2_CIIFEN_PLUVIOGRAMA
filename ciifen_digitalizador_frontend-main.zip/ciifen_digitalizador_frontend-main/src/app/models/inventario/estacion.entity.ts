export class Estacion {
  id: string;
  nombre: string;
  latitud: number;
  longitud: number;
  altitud: number;
}
