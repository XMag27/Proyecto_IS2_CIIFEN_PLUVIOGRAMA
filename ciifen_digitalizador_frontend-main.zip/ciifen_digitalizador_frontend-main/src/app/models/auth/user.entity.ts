export class User {
  nombres: String;
  usuario: String;
  email: String;
  access: String;
  refresh: String;
}
