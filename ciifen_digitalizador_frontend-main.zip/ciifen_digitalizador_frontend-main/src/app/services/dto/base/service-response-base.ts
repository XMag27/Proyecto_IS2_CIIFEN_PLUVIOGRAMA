export abstract class ServiceResponseBase {
  codigo: number;
  errorResponse: string;
}
