
export interface ServicePageResponse {
  count: number;
  next: string;
  previous: string;
  results: Array<any>;
}
