import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-solicitudes-infima-detail',
  templateUrl: './solicitudes-infima-detail.component.html',
  styleUrls: ['./solicitudes-infima-detail.component.scss']
})
export class SolicitudesInfimaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
