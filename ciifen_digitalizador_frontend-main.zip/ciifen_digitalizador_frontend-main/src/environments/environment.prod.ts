export const environment = {
  production: true,
  serverurl: "https://app.aspiradorabackend.net/api/v1/",
};
